//
//  AGCourse+CoreDataProperties.h
//  CoreData Part 3 Fetching  (Lesson 43)
//
//  Created by Anton Gorlov on 29.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGCourse.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGCourse (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSSet<AGStudent *> *students;
@property (nullable, nonatomic, retain) AGUniversity *university;
@property (nonatomic, retain) NSArray *bestStudents; //(это для Fetch Properties)если хотим работать как с проперти,то добавлем сюда
@property (nonatomic, retain) NSArray *studentsWithManyCoures; //(это для Fetch Properties) НЕ ЗАБЫВАЙ СТАВИТЬ @dynamic!!!!
@end

@interface AGCourse (CoreDataGeneratedAccessors)

- (void)addStudentsObject:(AGStudent *)value;
- (void)removeStudentsObject:(AGStudent *)value;
- (void)addStudents:(NSSet<AGStudent *> *)values;
- (void)removeStudents:(NSSet<AGStudent *> *)values;

@end

NS_ASSUME_NONNULL_END
