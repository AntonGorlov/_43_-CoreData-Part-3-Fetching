//
//  AGCourse.m
//  CoreData Part 3 Fetching  (Lesson 43)
//
//  Created by Anton Gorlov on 29.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCourse.h"
#import "AGStudent.h"
#import "AGUniversity.h"

@implementation AGCourse

// Insert code here to add functionality to your managed object subclass

@end
