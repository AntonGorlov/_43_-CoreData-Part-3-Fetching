//
//  AGObject+CoreDataProperties.h
//  CoreData Part 3 Fetching  (Lesson 43)
//
//  Created by Anton Gorlov on 29.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGObject (CoreDataProperties)


@end

NS_ASSUME_NONNULL_END
