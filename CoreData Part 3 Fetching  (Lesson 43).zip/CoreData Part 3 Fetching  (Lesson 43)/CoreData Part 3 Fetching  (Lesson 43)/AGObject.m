//
//  AGObject.m
//  CoreData Part 3 Fetching  (Lesson 43)
//
//  Created by Anton Gorlov on 29.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGObject.h"

@implementation AGObject

// Insert code here to add functionality to your managed object subclass

@end
