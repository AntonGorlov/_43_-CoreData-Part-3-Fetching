//
//  ViewController.h
//  CoreData Part 3 Fetching  (Lesson 43)
//
//  Created by Anton Gorlov on 28.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

